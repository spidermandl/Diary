package com.kemallette.RichEditText.Widget;

public interface SelectionChangeListener {

	public void onSelectionChanged(int selStart, int selEnd);
	
}
